from .PyRapier2d import *

__doc__ = PyRapier2d.__doc__
if hasattr(PyRapier2d, "__all__"):
    __all__ = PyRapier2d.__all__